<pre>
1. Describe possible performance optimizations for your Code.

Ans: App file should be improved becuase the way class and methods are getting include can be more clean & easy.
     Router file should be advance, currently its middle level.
	 My custom MVC framework is very optimized, simple and secured but can plan it to make that more secure.
	

2. Which things could be done better, than you’ve done it?

Ans: Architechture can be more better for more clean, secure and optimized code.
     can plan for HMVC in future version.
	 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 
I used MVC architecture for coding structure becuase I have experience in many MVC framework and I tried to develope my own custom MVC framework
to take my coding level to more upper level.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

custom mvc framwork in php 7 with mixers of Decorator, Factory and Singleton design patterns | suport of mysql and mssql databases.

@auther : Kuldeep Singh @email : rocky198811@gmail.com @version : 1.0

NOTE : EMAIL ME FOR FULL VERSION DEMO OF THIS CUSTOM MVC WHICH HAVE LOT OF FEATURES

Features:

1.Perticular files can be load on a view
2.Query debuggin mode
3.Query level logging
4.Application/PHP code level logging
5.Helpers : validation, catcha, email, upload, editor, date picker,
6.MYSQL and MSSQL Support
7.Routing
8.MVC secure architecture
9.CSRF, XSS, SQL injection security

</pre>
