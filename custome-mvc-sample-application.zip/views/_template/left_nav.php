<div class="left-nav">
	<a href="">Left Nan Link 1</a> |
	<a href="">Left Nan Link 2</a>
</div>
