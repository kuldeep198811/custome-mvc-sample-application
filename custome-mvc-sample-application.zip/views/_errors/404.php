<section class="error4_layout">
<div class="container">
	<div class="row">
		<div class="col-md-8 offset-md-2 error4_innerlayout">
			<div class="error4_text">404</div>
			<div class="error4_pagenotfound">Page not found</div>
			<div class="redirect_link"><a href="<?php echo $this->_basePath; ?>">Back to Home</a></div>
		</div>
	</div>
</div>
</section>