# Error Log
# Developer : Mohit Singh Rawat

##Uses 
=> Do "require 'ErrorLog.php'"; //filepath

=> Just Create object of this class and all error will logged automatically
$obj = new ErrorLog();

=> For exceptions capturing use in Your code
throw(new Exception('Your Exception message'));

