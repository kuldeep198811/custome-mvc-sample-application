/***
Wysihtml5 editor libaray 
@dev_name : Virendra Kumar
@description: 
__iniEditorLibs() function initialize wysihtml5 editor libaray.

__iniEditorImageUpload() function has jquery script for uploading image 

__editorTextField() function create text editor according given parameter.

__editorTextField() Parameter are  
 1-  $_id (mandatory)               textEdior id 
 2-  _name  (mandatory)             textEditor name
 3-  _optional array (optional)     optional array
     ['value'=>'','placeholder'=>'','rows'=>'','class'=>'']

     a- value has textEditor value
     b- placeholder has placeholder value
     c- rows has texteditor rows number
     d- class has extra addition class name 
 
***/