<?php

namespace EasyPost;

class Fee extends EasypostResource
{
    
}
