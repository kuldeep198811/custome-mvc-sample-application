<?php

namespace EasyPost;

class PostageLabel extends EasypostResource
{
    
}
