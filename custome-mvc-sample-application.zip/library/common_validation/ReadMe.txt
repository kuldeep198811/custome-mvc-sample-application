/****
 @dev_name:Manoj Joshi

 @description

**********************************************************

****  This library use for common validation in php.
****
**** For read documentation check commonValidation.doc document.

//==============================
//=============================================//


@endDescription
****/
