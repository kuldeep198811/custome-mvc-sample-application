# PHP Text
# Developer : Mohit Singh Rawat

##Uses 
=> Do "require 'PHPText.php'"; //filepath

1. Read text file :- 

call function __readFile($file); //$file is the text file


2. Write text file or add text in existing text file

call __writeFile($_file_path,$_data); // $_file_path is the text file path,$data which will be added

3. Write json data to file  

call __writeJsonData($_file_path,$_data) // $_file_path is the text file path,$data which will be added

4. Read json data from json file and return data as array type format

call __readJsonData($_file); //$file (.json file)



